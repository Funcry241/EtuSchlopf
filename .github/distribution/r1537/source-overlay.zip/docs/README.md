# Wegweiser durch die Dokumentation

EtuSchlopf ist ein experimentelles, privat gepflegtes Projekt. Beginne je nach
Aufgabe mit einem der folgenden Einstiege:

| Aufgabe | Einstieg |
| --- | --- |
| Zweck, Eingaben, Ausgaben und erster Lauf | [Projekt-README](../README.md) |
| Alle Aufrufe und Optionen | [Aufrufreferenz](../README.md#vollständige-aufrufreferenz) |
| Fehler melden oder etwas beitragen | [Beitragsleitfaden](CONTRIBUTING.md) |
| Sicherheitslücke melden | [Sicherheitsrichtlinie](SECURITY.md) |
| Umgang miteinander und Moderation | [Verhaltenskodex](CODE_OF_CONDUCT.md) |
| Bedienhürden und bekannte Grenzen | [Barrierefreiheit](ACCESSIBILITY.md) |
| Architektur und zuständige Verträge finden | [Architektureinstieg](assistant_memory/000_start_here.md) |
| Separate PDF-/Export-Diagnosen verwenden | [Diagnosewerkzeuge](../tools/assistant_diagnostics/README.md) |
| Lizenzen und Fremdkomponenten | [Fremdlizenzhinweise](THIRD_PARTY_NOTICES.md) |
| Community-Dateien auf GitHub veröffentlichen | [Veröffentlichungsablauf](community/GITHUB_PUBLISHING.md) |

Viele weitere Dateien in diesem Ordner dokumentieren einzelne Entwicklungsstände
und Entscheidungen. Eine historische Beschreibung ist kein Beleg für die aktuelle
Annahme oder das aktuelle Laufverhalten. Dafür gelten die zum konkreten Stand
gehörenden Verträge, Lifecycle-Belege und frischen Laufartefakte.
